package com.kiet.library.service;

import com.kiet.library.model.Book;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Business logic. Books are stored in a LinkedHashMap<Integer, Book>:
 *  - key = book id  -> O(1) lookup, update and delete by id
 *  - LinkedHashMap keeps insertion order when listing all books
 */
@Service
public class BookService {

    private final Map<Integer, Book> books = new LinkedHashMap<>();
    private int nextId = 1;

    public BookService() {
        // Sample data so GET works immediately
        addBook(new Book(null, "Clean Code", "Robert C. Martin", "Programming", 5));
        addBook(new Book(null, "Effective Java", "Joshua Bloch", "Programming", 3));
        addBook(new Book(null, "Wings of Fire", "A.P.J. Abdul Kalam", "Biography", 4));
    }

    /** Returns the saved book, or null if the given id already exists. */
    public synchronized Book addBook(Book book) {
        if (book.getId() == null) {
            while (books.containsKey(nextId)) {
                nextId++;
            }
            book.setId(nextId++);
        } else if (books.containsKey(book.getId())) {
            return null;
        }
        books.put(book.getId(), book);
        return book;
    }

    public synchronized List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }

    /** Returns the book, or null if not found. */
    public synchronized Book getBookById(Integer id) {
        return books.get(id);
    }

    /** Returns the updated book, or null if not found. */
    public synchronized Book updateBook(Integer id, Book updated) {
        Book existing = books.get(id);
        if (existing == null) {
            return null;
        }
        existing.setTitle(updated.getTitle());
        existing.setAuthor(updated.getAuthor());
        existing.setCategory(updated.getCategory());
        existing.setAvailableCopies(updated.getAvailableCopies());
        return existing;
    }

    /** Returns true if a book was deleted, false if not found. */
    public synchronized boolean deleteBook(Integer id) {
        return books.remove(id) != null;
    }
}
