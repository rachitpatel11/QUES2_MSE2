package com.kiet.library.controller;

import com.kiet.library.model.Book;
import com.kiet.library.service.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    // Q2-b : add a new book
    @PostMapping
    public ResponseEntity<?> addBook(@RequestBody Book book) {
        String error = validate(book);
        if (error != null) {
            return ResponseEntity.badRequest().body(error);
        }
        Book saved = bookService.addBook(book);
        if (saved == null) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("A book with id " + book.getId() + " already exists");
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // Q2-c : get all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookService.getAllBooks());
    }

    // Q2-c : get one book by id
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(@PathVariable Integer id) {
        Book book = bookService.getBookById(id);
        if (book == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found with id " + id);
        }
        return ResponseEntity.ok(book);
    }

    // Q2-d : update a book
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBook(@PathVariable Integer id, @RequestBody Book book) {
        String error = validate(book);
        if (error != null) {
            return ResponseEntity.badRequest().body(error);
        }
        Book updated = bookService.updateBook(id, book);
        if (updated == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found with id " + id);
        }
        return ResponseEntity.ok(updated);
    }

    // Q2-e : delete a book
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Integer id) {
        if (bookService.deleteBook(id)) {
            return ResponseEntity.ok("Book with id " + id + " deleted successfully");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found with id " + id);
    }

    /** Returns an error message, or null if the book is valid. */
    private String validate(Book book) {
        if (book.getTitle() == null || book.getTitle().trim().isEmpty()
                || book.getAuthor() == null || book.getAuthor().trim().isEmpty()) {
            return "Title and author are required";
        }
        if (book.getAvailableCopies() == null) {
            book.setAvailableCopies(0);
        }
        if (book.getAvailableCopies() < 0) {
            return "availableCopies cannot be negative";
        }
        return null;
    }
}
